package com.redsum.bos.dao;

import com.redsum.bos.entity.Waybill;
/**
 * 数据访问接口
 * @author Administrator
 *
 */
public interface IWaybillDao extends IBaseDao<Waybill>{

}
