package com.redsum.bos.biz;
import com.redsum.bos.entity.Waybilldetail;
/**
 * 业务逻辑层接口
 * @author Administrator
 *
 */
public interface IWaybilldetailBiz extends IBaseBiz<Waybilldetail>{

}

