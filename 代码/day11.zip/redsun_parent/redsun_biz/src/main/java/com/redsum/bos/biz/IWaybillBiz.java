package com.redsum.bos.biz;
import com.redsum.bos.entity.Waybill;
/**
 * 业务逻辑层接口
 * @author Administrator
 *
 */
public interface IWaybillBiz extends IBaseBiz<Waybill>{

}

