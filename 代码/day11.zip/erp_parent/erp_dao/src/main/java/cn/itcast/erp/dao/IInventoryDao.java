package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Inventory;
/**
 * 盘盈盘亏数据访问接口
 * @author Administrator
 *
 */
public interface IInventoryDao extends IBaseDao<Inventory>{

}
