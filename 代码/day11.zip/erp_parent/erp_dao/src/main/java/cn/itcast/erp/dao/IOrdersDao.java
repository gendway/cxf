package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Orders;
/**
 * 订单数据访问接口
 * @author Administrator
 *
 */
public interface IOrdersDao extends IBaseDao<Orders>{

}
