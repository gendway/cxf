package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Goods;
/**
 * 商品数据访问接口
 * @author Administrator
 *
 */
public interface IGoodsDao extends IBaseDao<Goods>{

}
