package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Supplier;
/**
 * 供应商数据访问接口
 * @author Administrator
 *
 */
public interface ISupplierDao extends IBaseDao<Supplier>{

}
