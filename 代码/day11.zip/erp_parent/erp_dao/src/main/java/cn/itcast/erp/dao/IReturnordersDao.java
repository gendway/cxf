package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Returnorders;
/**
 * 退货订单数据访问接口
 * @author Administrator
 *
 */
public interface IReturnordersDao extends IBaseDao<Returnorders>{

}
