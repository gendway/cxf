package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Storeoper;
/**
 * 仓库操作记录数据访问接口
 * @author Administrator
 *
 */
public interface IStoreoperDao extends IBaseDao<Storeoper>{

}
