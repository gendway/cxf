package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Store;
/**
 * 仓库数据访问接口
 * @author Administrator
 *
 */
public interface IStoreDao extends IBaseDao<Store>{

}
