package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Returnorderdetail;
/**
 * 退货订单明细数据访问接口
 * @author Administrator
 *
 */
public interface IReturnorderdetailDao extends IBaseDao<Returnorderdetail>{

}
