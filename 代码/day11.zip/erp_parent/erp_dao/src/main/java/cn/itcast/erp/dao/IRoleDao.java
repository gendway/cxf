package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Role;
/**
 * 角色数据访问接口
 * @author Administrator
 *
 */
public interface IRoleDao extends IBaseDao<Role>{

}
