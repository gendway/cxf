package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Dep;
/**
 * 部门数据访问接口
 * @author Administrator
 *
 */
public interface IDepDao extends IBaseDao<Dep>{

}
