package cn.itcast.erp.dao;

import cn.itcast.erp.entity.Orderdetail;
/**
 * 订单明细数据访问接口
 * @author Administrator
 *
 */
public interface IOrderdetailDao extends IBaseDao<Orderdetail>{

}
