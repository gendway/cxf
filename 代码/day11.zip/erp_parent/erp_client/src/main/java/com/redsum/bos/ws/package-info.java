@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.bos.redsum.com/")
package com.redsum.bos.ws;
