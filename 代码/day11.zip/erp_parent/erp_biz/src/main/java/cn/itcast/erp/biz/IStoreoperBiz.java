package cn.itcast.erp.biz;
import cn.itcast.erp.entity.Storeoper;
/**
 * 仓库操作记录业务逻辑层接口
 * @author Administrator
 *
 */
public interface IStoreoperBiz extends IBaseBiz<Storeoper>{

}

