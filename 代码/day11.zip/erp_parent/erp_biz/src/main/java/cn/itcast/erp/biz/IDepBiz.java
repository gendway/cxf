package cn.itcast.erp.biz;
import cn.itcast.erp.entity.Dep;
/**
 * 部门业务逻辑层接口
 * @author Administrator
 *
 */
public interface IDepBiz extends IBaseBiz<Dep>{

}

