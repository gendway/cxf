package cn.itcast.erp.biz;
import cn.itcast.erp.entity.Store;
/**
 * 仓库业务逻辑层接口
 * @author Administrator
 *
 */
public interface IStoreBiz extends IBaseBiz<Store>{

}

