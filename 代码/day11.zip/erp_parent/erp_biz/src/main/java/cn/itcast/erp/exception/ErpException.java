package cn.itcast.erp.exception;

public class ErpException extends RuntimeException {

	public ErpException(String message){
		super(message);
	}
}
