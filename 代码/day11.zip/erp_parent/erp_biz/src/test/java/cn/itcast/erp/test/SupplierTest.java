package cn.itcast.erp.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.itcast.erp.dao.IOrdersDao;
import cn.itcast.erp.entity.Orders;

public class SupplierTest {
	
	
	@Test
	public void testLogic(){
		/*ApplicationContext ac = new ClassPathXmlApplicationContext("classpath*:applicationContext*.xml");
		IOrdersDao ordersDao = (IOrdersDao)ac.getBean("supplierDao");
		Orders orders = ordersDao.get(5l);*/
		
	}
	

}
