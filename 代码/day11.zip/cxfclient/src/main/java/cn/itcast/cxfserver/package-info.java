@javax.xml.bind.annotation.XmlSchema(namespace = "http://cxfserver.itcast.cn/")
package cn.itcast.cxfserver;
